All **source code** is copyright © 2019 Andrew Belt and is licensed under the [GNU General Public License v3.0](LICENSE-GPLv3.txt).

The **VCV logo and icon** are copyright © 2017 Andrew Belt and may not be used in derivative works.

The **panel graphics** in the `res` directory are copyright © 2019 [Grayscale](http://grayscale.info/) and licensed under [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).
You may not distribute modified adaptations of these graphics.
